-- MySQL dump 10.13  Distrib 5.1.54, for debian-linux-gnu (i686)
--
-- Host: 91.204.162.80    Database: fullserver_map
-- ------------------------------------------------------
-- Server version	5.1.49-3-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fs_achievements`
--

DROP TABLE IF EXISTS `fs_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_achievements` (
  `name` varchar(32) NOT NULL,
  `shortname` varchar(8) NOT NULL,
  PRIMARY KEY (`shortname`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_achievements`
--

LOCK TABLES `fs_achievements` WRITE;
/*!40000 ALTER TABLE `fs_achievements` DISABLE KEYS */;
INSERT INTO `fs_achievements` VALUES ('Kolekcjoner walizek','WALIZKI'),('Zabojca','KILLS'),('Dlugie granie','LONGPLAY'),('Przejechanych km w wyscigach','RACEDIST'),('Ukonczonych wyscigow','RACEFCNT'),('Fan /DERBY','DERBYFAN'),('Zwyciezca /DERBY','DERBYWIN'),('Pirat drogowy','FOTOCASH'),('Drifting','DRIFTPTS');
/*!40000 ALTER TABLE `fs_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_achievements_ranks`
--

DROP TABLE IF EXISTS `fs_achievements_ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_achievements_ranks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shortname` varchar(8) CHARACTER SET ascii NOT NULL,
  `rank` varchar(32) NOT NULL,
  `score` int(10) unsigned NOT NULL,
  `replacename` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `shortname` (`shortname`),
  KEY `shortname_2` (`shortname`,`score`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_achievements_ranks`
--

LOCK TABLES `fs_achievements_ranks` WRITE;
/*!40000 ALTER TABLE `fs_achievements_ranks` DISABLE KEYS */;
INSERT INTO `fs_achievements_ranks` VALUES (1,'WALIZKI','Poczatkujacy kolekcjoner bonusow',5,1),(2,'WALIZKI','Wprawiony kolekcjoner bonusow',50,1),(3,'WALIZKI','Doswiadczony kolekcjoner bonusow',150,1),(4,'WALIZKI','Zapalony kolekcjoner bonusow',350,1),(5,'WALIZKI','Kolekcjoner bonusow - PRO',750,1),(6,'WALIZKI','Kolekcjoner bonusow - mistrz',1250,1),(7,'WALIZKI','Kolekcjoner bonusow - as',1750,1),(8,'WALIZKI','Kolekcjoner bonusow - guru',2500,1),(9,'KILLS','Poczatkujacy zabojca',15,1),(10,'KILLS','Wprawiony zabojca',50,1),(11,'KILLS','Doswiadczony zabojca',250,1),(12,'KILLS','Profesjonalny zabojca',500,1),(13,'KILLS','Seryjny morderca',1000,1),(14,'KILLS','Assassin',2000,1),(15,'KILLS','Eksterminator',4000,1),(16,'KILLS','Eradykator',8000,1),(17,'KILLS','Anihilator',16000,1),(18,'KILLS','Terminator',24000,1),(19,'KILLS','Bog zabijania',40000,1),(23,'LONGPLAY','Pelna godzina gry na FS',1,1),(24,'LONGPLAY','2h ciaglej gry',2,1),(25,'LONGPLAY','3h ciaglej gry',3,1),(26,'LONGPLAY','4h ciaglej gry',4,1),(27,'LONGPLAY','5h ciaglej gry',5,1),(28,'LONGPLAY','6h ciaglej gry',6,1),(29,'LONGPLAY','7h ciaglej gry',7,1),(30,'LONGPLAY','8h ciaglej gry',8,1),(31,'LONGPLAY','9h ciaglej gry',9,1),(32,'LONGPLAY','10h ciaglej gry',10,1),(33,'LONGPLAY','12h ciaglej gry',12,1),(34,'LONGPLAY','14h ciaglej gry',14,1),(35,'LONGPLAY','16h ciaglej gry',16,1),(36,'LONGPLAY','18h ciaglej gry',18,1),(37,'LONGPLAY','20h ciaglej gry',20,1),(38,'LONGPLAY','22h ciaglej gry',22,1),(39,'RACEDIST','100km przejechanych w wyscigach',100,1),(40,'RACEDIST','500km przejechanych w wyscigach',500,1),(41,'RACEDIST','1000km przejechanych w wyscigach',1000,1),(42,'RACEDIST','2000km przejechanych w wyscigach',2000,1),(43,'RACEDIST','5000km przejechanych w wyscigach',5000,1),(44,'RACEDIST','10000km przejechanych w wyscigac',10000,1),(45,'RACEDIST','15000km przejechanych w wyscigac',15000,1),(46,'RACEDIST','20000km przejechanych w wyscigac',20000,1),(47,'RACEDIST','30000km przejechanych w wyscigac',30000,1),(48,'RACEDIST','40000km przejechanych w wyscigac',40000,1),(49,'RACEDIST','60000km przejechanych w wyscigac',60000,1),(50,'RACEDIST','90000km przejechanych w wyscigac',90000,1),(51,'RACEFCNT','Pierwszy ukonczony wyscig!',1,1),(52,'RACEFCNT','10',10,0),(53,'RACEFCNT','50',50,0),(54,'RACEFCNT','100',100,0),(55,'RACEFCNT','250',250,0),(56,'RACEFCNT','500',500,0),(57,'RACEFCNT','1000',1000,0),(58,'RACEFCNT','2000',2000,0),(59,'RACEFCNT','4000',4000,0),(60,'DERBYFAN','10 rozegranych pojedynkow',10,0),(61,'DERBYFAN','25 rozegranych pojedynkow',25,0),(62,'DERBYFAN','50 rozegranych pojedynkow',50,0),(63,'DERBYFAN','100 rozegranych pojedynkow',100,0),(64,'DERBYFAN','200 rozegranych pojedynkow',200,0),(65,'DERBYFAN','400 rozegranych pojedynkow',400,0),(66,'DERBYFAN','800 rozegranych pojedynkow',800,0),(67,'DERBYFAN','1600 rozegranych pojedynkow',1600,0),(68,'DERBYFAN','3200 rozegranych pojedynkow',3200,0),(69,'DERBYWIN','Pierwsze zwyciestwo!',1,0),(70,'DERBYWIN','10 zwyciestw!',10,0),(71,'DERBYWIN','20 zwyciestw!',20,0),(72,'DERBYWIN','50 zwyciestw!',50,0),(73,'DERBYWIN','100 zwyciestw!',100,0),(74,'DERBYWIN','150 zwyciestw!',150,0),(75,'DERBYWIN','200 zwyciestw!',200,0),(76,'DERBYWIN','250 zwyciestw!',250,0),(77,'DERBYWIN','300 zwyciestw!',300,0),(78,'DERBYWIN','400 zwyciestw!',400,0),(79,'DERBYWIN','500 zwyciestw!',500,0),(80,'DERBYWIN','600 zwyciestw!',600,0),(81,'FOTOCASH','przylapany!',1,0),(82,'FOTOCASH','100$ mandatow',100,0),(83,'FOTOCASH','1000$ mandatow',1000,0),(84,'FOTOCASH','5000$ mandatow',5000,0),(85,'FOTOCASH','25000$ mandatow',25000,0),(86,'FOTOCASH','50000$ mandatow',50000,0),(87,'FOTOCASH','100000$ mandatow',100000,0),(88,'FOTOCASH','200000$ mandatow',200000,0),(89,'FOTOCASH','500000$ mandatow',500000,0),(90,'FOTOCASH','1 000 000$ mandatow',1000000,0),(91,'FOTOCASH','10 000 000$ mandatow',10000000,0),(92,'DRIFTPTS','nowicjusz',1,0),(93,'DRIFTPTS','poczatkujacy',3000,0),(94,'DRIFTPTS','amator',30000,0),(95,'DRIFTPTS','Full Drifter',300000,0),(96,'DRIFTPTS','Krol Driftu',900000,0),(97,'DRIFTPTS','Legenda Driftu',9000000,0);
/*!40000 ALTER TABLE `fs_achievements_ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_arena`
--

DROP TABLE IF EXISTS `fs_arena`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_arena` (
  `id` int(10) unsigned NOT NULL,
  `descr` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_arena`
--

LOCK TABLES `fs_arena` WRITE;
/*!40000 ALTER TABLE `fs_arena` DISABLE KEYS */;
INSERT INTO `fs_arena` VALUES (1,'/arenasolo'),(3,'/rpg'),(4,'/minigun'),(5,'/pro'),(6,'/onede'),(7,'/onede2'),(8,'/aztec'),(9,'/oneshoot'),(10,'/sniper'),(11,'/pier'),(12,'/arenaso'),(13,'/jp');
/*!40000 ALTER TABLE `fs_arena` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_bans`
--

DROP TABLE IF EXISTS `fs_bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_banned` int(11) NOT NULL,
  `player_given` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_end` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reason` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `player_banned` (`player_banned`,`date_created`,`date_end`)
) ENGINE=MyISAM AUTO_INCREMENT=2520 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_bans`
--

LOCK TABLES `fs_bans` WRITE;
/*!40000 ALTER TABLE `fs_bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_cenzura`
--

DROP TABLE IF EXISTS `fs_cenzura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_cenzura` (
  `find` varchar(64) NOT NULL,
  `repl` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_cenzura`
--

LOCK TABLES `fs_cenzura` WRITE;
/*!40000 ALTER TABLE `fs_cenzura` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_cenzura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_chowany_arena`
--

DROP TABLE IF EXISTS `fs_chowany_arena`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_chowany_arena` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descr` varchar(64) NOT NULL,
  `interior` smallint(5) unsigned NOT NULL DEFAULT '0',
  `minplayers` smallint(5) unsigned NOT NULL DEFAULT '2',
  `maxplayers` smallint(5) unsigned NOT NULL DEFAULT '2',
  `wb_cube` varchar(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT 'prostopadloscian x1,y1,z1,x2,y2,z2',
  `wb_mode` enum('oraz','lub') CHARACTER SET ascii NOT NULL DEFAULT 'lub' COMMENT 'oraz - gracz musi byc w obu polach, lub - musi byc w jednym z nich',
  `wb_sphere` varchar(64) CHARACTER SET ascii DEFAULT NULL COMMENT 'kula/sfera: x,y,z,r',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_chowany_arena`
--

LOCK TABLES `fs_chowany_arena` WRITE;
/*!40000 ALTER TABLE `fs_chowany_arena` DISABLE KEYS */;
INSERT INTO `fs_chowany_arena` VALUES (1,'Plac budowy w LV',0,3,23,'2372,1823,5,2497,1963,25','lub',NULL);
/*!40000 ALTER TABLE `fs_chowany_arena` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_chowany_arena_sp`
--

DROP TABLE IF EXISTS `fs_chowany_arena_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_chowany_arena_sp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL,
  `team` tinyint(1) unsigned NOT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `A` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1920 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_chowany_arena_sp`
--

LOCK TABLES `fs_chowany_arena_sp` WRITE;
/*!40000 ALTER TABLE `fs_chowany_arena_sp` DISABLE KEYS */;
INSERT INTO `fs_chowany_arena_sp` VALUES (178,1,1,2403.1308,1827.4095,11.6562,180.81),(179,1,0,2376.3007,1834.9986,11.6562,93.07),(180,1,0,2379.927,1837.1065,11.6562,3.07),(181,1,0,2376.5241,1838.6791,11.6562,109.92),(182,1,0,2379.2607,1841.2999,11.6562,193.34),(183,1,0,2382.8303,1838.3653,11.6562,193.34),(184,1,0,2381.8337,1834.5617,11.6562,206.64),(185,1,0,2385.7661,1835.854,11.6562,179.31),(186,1,0,2388.6335,1834.2847,11.6562,257.72),(187,1,0,2376.269,1843.7717,11.6562,285.53),(188,1,1,2446.04,1960.628,10.772,5.05),(189,1,0,2445.4768,1949.7839,10.6738,172.11),(190,1,0,2445.0383,1945.182,10.8203,2.83),(191,1,0,2449.0363,1945.1276,10.5525,355.55),(192,1,0,2449.3627,1950.02,10.6284,356.18),(193,1,0,2445.6313,1954.1923,10.744,357.99),(194,1,0,2449.4533,1954.5474,10.7013,177.99),(195,1,0,2452.9897,1954.8702,10.5493,276.83),(196,1,0,2452.9758,1950.4141,10.4666,90.57),(197,1,0,2453.1872,1945.09,10.3445,0.56),(198,1,1,2495.7849,1961.0573,10.8203,323.98),(199,1,1,2449.3469,1960.6145,10.7717,0.93),(200,1,1,2442.5966,1960.5268,10.7986,2.47),(303,1,1,2378.2695,1878.5788,11.6562,46.33),(304,1,1,2381.1376,1881.5863,11.6562,86.44),(305,1,1,2374.2148,1959.8656,11.6562,40.38),(306,1,1,2442.2587,1960.5277,10.8029,359.67),(307,1,1,2442.749,1954.0914,10.779,91.77),(308,1,1,2473.018,1945.2327,10.1484,268.8),(309,1,0,2430.4897,1909.1365,6.0156,180.8),(310,1,0,2426.113,1908.6325,6.0156,180.8),(311,1,0,2421.947,1908.885,6.0156,270.81),(312,1,0,2424.2944,1913.2646,6.0156,272.93),(313,1,0,2428.3544,1913.4724,6.0156,272.93),(314,1,0,2410.9528,1938.8081,6.0156,273.88),(315,1,0,2410.8896,1933.4722,6.0156,263.54),(316,1,0,2410.8103,1926.6575,6.0156,275.44),(317,1,0,2409.8085,1918.8927,6.0156,274.19),(318,1,0,2409.6252,1911.7425,6.0156,274.5),(319,1,0,2409.1503,1904.0729,6.0156,267.92),(320,1,0,2408.8498,1897.8815,6.0156,274.19);
/*!40000 ALTER TABLE `fs_chowany_arena_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_config`
--

DROP TABLE IF EXISTS `fs_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_config` (
  `option_name` varchar(32) NOT NULL,
  `value` text,
  PRIMARY KEY (`option_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_config`
--

LOCK TABLES `fs_config` WRITE;
/*!40000 ALTER TABLE `fs_config` DISABLE KEYS */;
INSERT INTO `fs_config` VALUES ('admin_password','85d392307e0ed2b5d12a4a1fdff00bbf'),('welcome_text','Gratulacje! Uruchomiles wlasnie swoj wlasny serwer z gamemodem XyzzyDM. Przeczytaj instrukcje zawarte na FTP aby dowiedziec sie, co robic dalej aby go ustawic :-)');
/*!40000 ALTER TABLE `fs_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_derby_arena`
--

DROP TABLE IF EXISTS `fs_derby_arena`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_derby_arena` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `minPlayers` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `maxPlayers` tinyint(3) unsigned NOT NULL DEFAULT '4',
  `vehicle` smallint(5) unsigned NOT NULL DEFAULT '444',
  `interior` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `descr` varchar(255) DEFAULT NULL,
  `nitro` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `minPlayers` (`minPlayers`,`maxPlayers`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_derby_arena`
--

LOCK TABLES `fs_derby_arena` WRITE;
/*!40000 ALTER TABLE `fs_derby_arena` DISABLE KEYS */;
INSERT INTO `fs_derby_arena` VALUES (4,4,10,466,0,'LS Stadium',0);
/*!40000 ALTER TABLE `fs_derby_arena` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_derby_arena_sp`
--

DROP TABLE IF EXISTS `fs_derby_arena_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_derby_arena_sp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `angle` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=401 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_derby_arena_sp`
--

LOCK TABLES `fs_derby_arena_sp` WRITE;
/*!40000 ALTER TABLE `fs_derby_arena_sp` DISABLE KEYS */;
INSERT INTO `fs_derby_arena_sp` VALUES (13,4,2684.84,-1735.51,38.84,233.01),(14,4,2705.76,-1717.87,40.02,203.56),(15,4,2734.67,-1707.53,40.09,181.31),(16,4,2755.96,-1716.53,41.15,155.62),(17,4,2778.77,-1733.5,40.91,125.85),(18,4,2785.74,-1754.03,41.07,103.6),(19,4,2777.99,-1777.65,41.44,77.91),(20,4,2757.57,-1798.63,41.5,44.38),(21,4,2734.81,-1810.56,40.62,18.06),(22,4,2705.07,-1798.23,40.7,321.66);
/*!40000 ALTER TABLE `fs_derby_arena_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_dragrace_records`
--

DROP TABLE IF EXISTS `fs_dragrace_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_dragrace_records` (
  `id_player` int(10) unsigned NOT NULL,
  `vehicleModel` int(10) unsigned NOT NULL,
  `time` double(6,3) unsigned NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ping` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_dragrace_records`
--

LOCK TABLES `fs_dragrace_records` WRITE;
/*!40000 ALTER TABLE `fs_dragrace_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_dragrace_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_drift_records`
--

DROP TABLE IF EXISTS `fs_drift_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_drift_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `playerid` int(10) unsigned NOT NULL,
  `raceid` smallint(10) unsigned NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recordtime` float unsigned NOT NULL,
  `opponents` mediumint(9) NOT NULL DEFAULT '1',
  `finalscore` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `raceid` (`raceid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_drift_records`
--

LOCK TABLES `fs_drift_records` WRITE;
/*!40000 ALTER TABLE `fs_drift_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_drift_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_drift_tracks`
--

DROP TABLE IF EXISTS `fs_drift_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_drift_tracks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `minPlayers` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `maxPlayers` tinyint(3) unsigned NOT NULL DEFAULT '10',
  `vehicle` smallint(5) unsigned NOT NULL DEFAULT '444',
  `interior` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `descr` varchar(255) DEFAULT NULL,
  `nitro` tinyint(1) NOT NULL DEFAULT '0',
  `allowRepairs` tinyint(1) NOT NULL DEFAULT '0',
  `allowFlip` tinyint(1) NOT NULL DEFAULT '0',
  `distance` double unsigned NOT NULL DEFAULT '100',
  `scx` double DEFAULT NULL,
  `scy` double DEFAULT NULL,
  `scz` double DEFAULT NULL,
  `limitrand` tinyint(4) NOT NULL DEFAULT '100',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `partime` float unsigned NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`),
  KEY `minPlayers` (`minPlayers`,`maxPlayers`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_drift_tracks`
--

LOCK TABLES `fs_drift_tracks` WRITE;
/*!40000 ALTER TABLE `fs_drift_tracks` DISABLE KEYS */;
INSERT INTO `fs_drift_tracks` VALUES (1,1,4,562,0,'Whetstone-SF',1,0,1,7.61,-1208,-1340,125,100,1,70);
/*!40000 ALTER TABLE `fs_drift_tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_drift_tracks_cp`
--

DROP TABLE IF EXISTS `fs_drift_tracks_cp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_drift_tracks_cp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `type` smallint(3) unsigned NOT NULL DEFAULT '0',
  `size` double NOT NULL DEFAULT '0',
  `so` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=173 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_drift_tracks_cp`
--

LOCK TABLES `fs_drift_tracks_cp` WRITE;
/*!40000 ALTER TABLE `fs_drift_tracks_cp` DISABLE KEYS */;
INSERT INTO `fs_drift_tracks_cp` VALUES (1,1,-1313.3303,-1382.2213,114.9432,0,8,10),(2,1,-1438.3789,-1371.8485,100.4976,0,8,20),(3,1,-1535.4415,-1211.212,101.5911,0,8,30),(4,1,-1633.6191,-1067.8106,102.3323,0,8,40),(5,1,-1633.9532,-941.07,99.6561,0,8,50),(6,1,-1644.8942,-806.4486,90.2577,0,8,60),(7,1,-1746.9104,-965.1956,75.193,0,8,70),(8,1,-1638.175,-1175.7503,70.7841,0,8,80),(9,1,-1531.8688,-1344.4409,49.8176,0,8,90),(10,1,-1568.3386,-1439.1719,40.5517,0,8,100),(11,1,-1668.5269,-1308.208,49.0325,0,8,110);
/*!40000 ALTER TABLE `fs_drift_tracks_cp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_drift_tracks_sp`
--

DROP TABLE IF EXISTS `fs_drift_tracks_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_drift_tracks_sp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `angle` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_drift_tracks_sp`
--

LOCK TABLES `fs_drift_tracks_sp` WRITE;
/*!40000 ALTER TABLE `fs_drift_tracks_sp` DISABLE KEYS */;
INSERT INTO `fs_drift_tracks_sp` VALUES (1,1,-1241.2508,-1355.632,120.8745,110),(2,1,-1239.7203,-1350.4467,121.091,109.5),(3,1,-1233.2492,-1352.8937,121.4565,108),(4,1,-1229.5098,-1347.4852,121.7946,106.2);
/*!40000 ALTER TABLE `fs_drift_tracks_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_entrances`
--

DROP TABLE IF EXISTS `fs_entrances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_entrances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pickuptype` smallint(5) unsigned NOT NULL DEFAULT '1318',
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `worldid` smallint(6) NOT NULL DEFAULT '-1',
  `interiorid` tinyint(4) NOT NULL DEFAULT '-1',
  `distance` double unsigned NOT NULL DEFAULT '300',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_entrances`
--

LOCK TABLES `fs_entrances` WRITE;
/*!40000 ALTER TABLE `fs_entrances` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_entrances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_gangs`
--

DROP TABLE IF EXISTS `fs_gangs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_gangs` (
  `id` smallint(1) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `tag` varchar(5) NOT NULL,
  `color` char(6) NOT NULL DEFAULT '000000',
  `respect` int(11) NOT NULL DEFAULT '0',
  `datetime_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `basespawn` varchar(64) NOT NULL DEFAULT '2023,1008,12,270' COMMENT 'Miejsce spawnu gangu - BAZA',
  `spawnpoint` varchar(64) NOT NULL DEFAULT '2023,1008,11,270',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `tag` (`tag`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_gangs`
--

LOCK TABLES `fs_gangs` WRITE;
/*!40000 ALTER TABLE `fs_gangs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_gangs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_houses`
--

DROP TABLE IF EXISTS `fs_houses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_houses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descr` varchar(64) CHARACTER SET utf8 DEFAULT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `ownerid` int(10) unsigned DEFAULT NULL,
  `koszt` smallint(4) unsigned NOT NULL DEFAULT '0',
  `exitX` float NOT NULL DEFAULT '0',
  `exitY` float NOT NULL DEFAULT '0',
  `exitZ` float NOT NULL DEFAULT '0',
  `exitA` float NOT NULL DEFAULT '0',
  `paidTo` date DEFAULT NULL,
  `homeX` float NOT NULL,
  `homeY` float NOT NULL,
  `homeZ` float NOT NULL,
  `homeA` float NOT NULL,
  `homeI` smallint(6) NOT NULL,
  `homeVW` mediumint(9) NOT NULL DEFAULT '-1',
  `vehicles_allowed` tinyint(4) NOT NULL DEFAULT '1',
  `vehicle_radius` double unsigned NOT NULL DEFAULT '20',
  `audioURL` varchar(128) DEFAULT NULL,
  `restrict_gang` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ownerid` (`ownerid`)
) ENGINE=MyISAM AUTO_INCREMENT=646 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_houses`
--

LOCK TABLES `fs_houses` WRITE;
/*!40000 ALTER TABLE `fs_houses` DISABLE KEYS */;
INSERT INTO `fs_houses` VALUES (1,'Grove Street',2486.42,-1644.53,14.07,29885,350,2486.42,-1647.99,14.0703,181.621,'2012-02-21',2318.14,-1025.23,1050.21,320.429,9,-1,1,20,NULL,0);
/*!40000 ALTER TABLE `fs_houses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_houses_old`
--

DROP TABLE IF EXISTS `fs_houses_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_houses_old` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pickup_c` varchar(50) NOT NULL,
  `entry_c` varchar(64) NOT NULL,
  `entry_teleport_c` varchar(64) NOT NULL,
  `exit_teleport_c` varchar(64) NOT NULL,
  `interior` tinyint(3) unsigned NOT NULL,
  `owner_id` int(10) NOT NULL,
  `vehicle_c` varchar(64) NOT NULL,
  `vehicle` smallint(5) unsigned NOT NULL,
  `vehicle_color` tinyint(3) unsigned NOT NULL,
  `locked` tinyint(1) NOT NULL,
  `paid` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `preview_camera_pos_c` varchar(50) NOT NULL,
  `preview_camera_look_c` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_owner` (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_houses_old`
--

LOCK TABLES `fs_houses_old` WRITE;
/*!40000 ALTER TABLE `fs_houses_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_houses_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_houses_vehicles`
--

DROP TABLE IF EXISTS `fs_houses_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_houses_vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `houseid` int(10) unsigned NOT NULL,
  `model` smallint(5) unsigned NOT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `A` double NOT NULL,
  `color1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `color2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `plate` varchar(32) NOT NULL DEFAULT 'bryka',
  `components` varchar(80) NOT NULL DEFAULT ' ',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10370 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_houses_vehicles`
--

LOCK TABLES `fs_houses_vehicles` WRITE;
/*!40000 ALTER TABLE `fs_houses_vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_houses_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_ipbans`
--

DROP TABLE IF EXISTS `fs_ipbans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_ipbans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(24) NOT NULL,
  `player_given` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_end` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reason` text NOT NULL,
  `target_nick` varchar(32) DEFAULT NULL,
  `target_accountid` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`,`date_end`)
) ENGINE=MyISAM AUTO_INCREMENT=6091 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_ipbans`
--

LOCK TABLES `fs_ipbans` WRITE;
/*!40000 ALTER TABLE `fs_ipbans` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_ipbans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_mapicons`
--

DROP TABLE IF EXISTS `fs_mapicons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_mapicons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mapicon` smallint(6) NOT NULL DEFAULT '1',
  `pX` double NOT NULL,
  `pY` double NOT NULL,
  `pZ` double NOT NULL,
  `pi` mediumint(9) NOT NULL DEFAULT '0',
  `pvw` mediumint(9) NOT NULL DEFAULT '0',
  `opis` varchar(64) DEFAULT NULL,
  `type` smallint(1) unsigned NOT NULL DEFAULT '1',
  `loadingdistance` int(10) unsigned NOT NULL DEFAULT '1200',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_mapicons`
--

LOCK TABLES `fs_mapicons` WRITE;
/*!40000 ALTER TABLE `fs_mapicons` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_mapicons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_miscpickups`
--

DROP TABLE IF EXISTS `fs_miscpickups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_miscpickups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pickupid` mediumint(8) unsigned NOT NULL DEFAULT '371',
  `interior` int(11) NOT NULL DEFAULT '0',
  `vw` int(11) NOT NULL DEFAULT '0',
  `pX` double NOT NULL,
  `pY` double NOT NULL,
  `pZ` double NOT NULL,
  `descr` varchar(64) DEFAULT NULL,
  `addedby` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=377 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_miscpickups`
--

LOCK TABLES `fs_miscpickups` WRITE;
/*!40000 ALTER TABLE `fs_miscpickups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_miscpickups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_players`
--

DROP TABLE IF EXISTS `fs_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_players` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nick` varchar(24) CHARACTER SET ascii NOT NULL,
  `password` varchar(32) NOT NULL,
  `ip_registered` varchar(16) NOT NULL,
  `ip_last` varchar(16) NOT NULL,
  `datetime_registered` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `datetime_last` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `session` bigint(11) NOT NULL,
  `level` tinyint(4) NOT NULL,
  `vip` date NOT NULL,
  `gang` int(11) NOT NULL,
  `language` tinyint(4) NOT NULL,
  `ban_count` mediumint(9) NOT NULL,
  `kick_count` mediumint(9) NOT NULL,
  `login_count` mediumint(9) NOT NULL,
  `kill_count` mediumint(9) NOT NULL,
  `teamkill_count` mediumint(9) NOT NULL,
  `death_count` mediumint(9) NOT NULL,
  `suicide_count` mediumint(9) NOT NULL,
  `respect` int(11) NOT NULL,
  `skill` mediumint(9) NOT NULL,
  `next_nick_change` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bank_money` int(11) NOT NULL,
  `wallet_money` int(11) NOT NULL,
  `hitman_prize` int(11) NOT NULL,
  `jail` mediumint(9) NOT NULL DEFAULT '-1',
  `last_skin` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mute` mediumint(9) NOT NULL DEFAULT '0',
  `hud0` tinyint(1) NOT NULL DEFAULT '1',
  `hud1` tinyint(1) NOT NULL DEFAULT '1',
  `hud2` tinyint(1) NOT NULL DEFAULT '1',
  `hud3` tinyint(1) NOT NULL DEFAULT '1',
  `hud4` tinyint(1) NOT NULL DEFAULT '1',
  `hud5` tinyint(1) NOT NULL DEFAULT '1',
  `hud6` tinyint(1) NOT NULL DEFAULT '1',
  `hud7` tinyint(1) NOT NULL DEFAULT '1',
  `hud8` tinyint(1) NOT NULL DEFAULT '1',
  `gender` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nick` (`nick`),
  KEY `session` (`session`),
  KEY `respect` (`respect`),
  KEY `skill` (`skill`),
  FULLTEXT KEY `ip_last` (`ip_last`)
) ENGINE=MyISAM AUTO_INCREMENT=17008 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_players`
--

LOCK TABLES `fs_players` WRITE;
/*!40000 ALTER TABLE `fs_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_players_achievements`
--

DROP TABLE IF EXISTS `fs_players_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_players_achievements` (
  `playerid` int(10) unsigned NOT NULL,
  `shortname` enum('DERBYFAN','DERBYWIN','KILLS','LONGPLAY','RACEDIST','RACEFCNT','WALIZKI','FOTOCASH') CHARACTER SET ascii NOT NULL,
  `score` int(10) unsigned NOT NULL,
  PRIMARY KEY (`playerid`,`shortname`),
  KEY `shortname` (`shortname`,`score`),
  KEY `playerid` (`playerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_players_achievements`
--

LOCK TABLES `fs_players_achievements` WRITE;
/*!40000 ALTER TABLE `fs_players_achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_players_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_players_arenascore`
--

DROP TABLE IF EXISTS `fs_players_arenascore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_players_arenascore` (
  `id_player` int(10) unsigned NOT NULL,
  `id_arena` smallint(5) unsigned NOT NULL,
  `kills` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_player`,`id_arena`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_players_arenascore`
--

LOCK TABLES `fs_players_arenascore` WRITE;
/*!40000 ALTER TABLE `fs_players_arenascore` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_players_arenascore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_players_arenascore_week`
--

DROP TABLE IF EXISTS `fs_players_arenascore_week`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_players_arenascore_week` (
  `id_player` int(10) unsigned NOT NULL,
  `id_arena` smallint(5) unsigned NOT NULL,
  `kills` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_player`,`id_arena`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_players_arenascore_week`
--

LOCK TABLES `fs_players_arenascore_week` WRITE;
/*!40000 ALTER TABLE `fs_players_arenascore_week` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_players_arenascore_week` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_players_in_gangs`
--

DROP TABLE IF EXISTS `fs_players_in_gangs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_players_in_gangs` (
  `id_gang` smallint(1) unsigned NOT NULL,
  `id_player` int(10) unsigned NOT NULL,
  `rank` enum('member','owner','leader','suspended') NOT NULL DEFAULT 'member',
  `join_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_gang`,`id_player`),
  KEY `player_in_gang` (`id_player`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_players_in_gangs`
--

LOCK TABLES `fs_players_in_gangs` WRITE;
/*!40000 ALTER TABLE `fs_players_in_gangs` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_players_in_gangs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_players_notes`
--

DROP TABLE IF EXISTS `fs_players_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_players_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `player_id` int(10) unsigned NOT NULL,
  `author` int(10) unsigned NOT NULL,
  `note` text,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_players_notes`
--

LOCK TABLES `fs_players_notes` WRITE;
/*!40000 ALTER TABLE `fs_players_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_players_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_premium`
--

DROP TABLE IF EXISTS `fs_premium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_premium` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) NOT NULL DEFAULT 'unknown',
  `UA` varchar(64) NOT NULL DEFAULT 'Unknown',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `accountid` int(10) unsigned DEFAULT NULL,
  `type` varchar(64) NOT NULL,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_premium`
--

LOCK TABLES `fs_premium` WRITE;
/*!40000 ALTER TABLE `fs_premium` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_premium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_races`
--

DROP TABLE IF EXISTS `fs_races`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_races` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `minPlayers` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `maxPlayers` tinyint(3) unsigned NOT NULL DEFAULT '10',
  `vehicle` smallint(5) unsigned NOT NULL DEFAULT '444',
  `interior` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `descr` varchar(255) DEFAULT NULL,
  `nitro` tinyint(1) NOT NULL DEFAULT '0',
  `allowRepairs` tinyint(1) NOT NULL DEFAULT '0',
  `allowFlip` tinyint(1) NOT NULL DEFAULT '0',
  `distance` double unsigned NOT NULL DEFAULT '100',
  `scx` double DEFAULT NULL,
  `scy` double DEFAULT NULL,
  `scz` double DEFAULT NULL,
  `limitrand` tinyint(4) NOT NULL DEFAULT '100',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `minPlayers` (`minPlayers`,`maxPlayers`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_races`
--

LOCK TABLES `fs_races` WRITE;
/*!40000 ALTER TABLE `fs_races` DISABLE KEYS */;
INSERT INTO `fs_races` VALUES (2,1,4,489,0,'Tierra Robada',1,0,1,10.02,-1254.01,2687.22,63.57,100,1);
/*!40000 ALTER TABLE `fs_races` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_races_cp`
--

DROP TABLE IF EXISTS `fs_races_cp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_races_cp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `type` smallint(3) unsigned NOT NULL DEFAULT '0',
  `size` double NOT NULL DEFAULT '0',
  `so` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=1572 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_races_cp`
--

LOCK TABLES `fs_races_cp` WRITE;
/*!40000 ALTER TABLE `fs_races_cp` DISABLE KEYS */;
INSERT INTO `fs_races_cp` VALUES (12,2,-1057.7505,2142.8457,87.5362,0,8,40),(11,2,-1242.6707,1921.2308,43.0445,0,8,30),(10,2,-1355.7784,2172.2126,48.6469,0,8,20),(9,2,-1479.0613,2111.4155,45.6613,0,8,10),(5,2,-1379.1201,2597.791,55.5048,0,8,2),(6,2,-1224.9153,2683.946,46.5368,0,8,1),(7,2,-1440.3073,2370.1321,53.2331,0,8,3),(8,2,-1528.4592,2362.9968,46.7244,0,8,4),(13,2,-1112.5997,2367.0562,85.2033,0,8,50),(14,2,-1214.1082,2219.0828,105.8066,0,8,60),(15,2,-1297.2722,2498.7354,87.105,1,8,70);
/*!40000 ALTER TABLE `fs_races_cp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_races_records`
--

DROP TABLE IF EXISTS `fs_races_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_races_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `playerid` int(10) unsigned NOT NULL,
  `raceid` smallint(10) unsigned NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recordtime` float unsigned NOT NULL,
  `opponents` mediumint(9) NOT NULL DEFAULT '1',
  `finalposition` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `raceid` (`raceid`)
) ENGINE=MyISAM AUTO_INCREMENT=103023 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_races_records`
--

LOCK TABLES `fs_races_records` WRITE;
/*!40000 ALTER TABLE `fs_races_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_races_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_races_sp`
--

DROP TABLE IF EXISTS `fs_races_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_races_sp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `angle` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM AUTO_INCREMENT=550 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_races_sp`
--

LOCK TABLES `fs_races_sp` WRITE;
/*!40000 ALTER TABLE `fs_races_sp` DISABLE KEYS */;
INSERT INTO `fs_races_sp` VALUES (1,2,-1185.7988,2687.7388,46.0117,97),(2,2,-1193.4845,2692.7375,46.011,97),(3,2,-1192.7256,2686.7903,46.0118,97),(4,2,-1199.8636,2685.8145,46.0118,97),(5,2,-1200.6205,2691.7932,46.0117,97),(6,2,-1186.4705,2693.6794,46.0113,97),(7,2,-1178.7043,2688.6162,46.0122,97),(8,2,-1179.5155,2694.4751,46.0111,97),(9,2,-1172.1554,2689.4785,46.0122,97),(10,2,-1172.9631,2695.2019,46.0116,97);
/*!40000 ALTER TABLE `fs_races_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_returnpickups`
--

DROP TABLE IF EXISTS `fs_returnpickups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_returnpickups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pX` double NOT NULL,
  `pY` double NOT NULL,
  `pZ` double NOT NULL,
  `pi` int(11) NOT NULL,
  `pvw` int(11) NOT NULL,
  `opis` varchar(64) DEFAULT NULL,
  `pickupid` int(10) unsigned NOT NULL DEFAULT '19197',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_returnpickups`
--

LOCK TABLES `fs_returnpickups` WRITE;
/*!40000 ALTER TABLE `fs_returnpickups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_returnpickups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_solo_matches`
--

DROP TABLE IF EXISTS `fs_solo_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_solo_matches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `arenaid` smallint(5) unsigned NOT NULL,
  `weapon1` tinyint(3) unsigned NOT NULL,
  `weapon2` tinyint(3) unsigned NOT NULL,
  `playerid` int(10) unsigned NOT NULL,
  `killerid` int(10) unsigned NOT NULL,
  `fightlen` mediumint(8) unsigned NOT NULL,
  `hp` tinyint(3) unsigned NOT NULL,
  `ar` tinyint(3) unsigned NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19159 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_solo_matches`
--

LOCK TABLES `fs_solo_matches` WRITE;
/*!40000 ALTER TABLE `fs_solo_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_solo_matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_stats`
--

DROP TABLE IF EXISTS `fs_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_stats` (
  `option_name` varchar(32) NOT NULL,
  `value` blob,
  PRIMARY KEY (`option_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_stats`
--

LOCK TABLES `fs_stats` WRITE;
/*!40000 ALTER TABLE `fs_stats` DISABLE KEYS */;
INSERT INTO `fs_stats` VALUES ('most_online','1'),('most_online_date','2012-02-21 13:30:58'),('join_count',NULL),('kill_count',NULL),('death_count',NULL),('kick_count',NULL),('ban_count',NULL);
/*!40000 ALTER TABLE `fs_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_telecheckpoints`
--

DROP TABLE IF EXISTS `fs_telecheckpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_telecheckpoints` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fPOS` varchar(64) NOT NULL COMMENT 'X,Y,Z,A,interior',
  `fOPIS` varchar(64) DEFAULT NULL COMMENT 'opis na 3dtextlabel i gametext',
  `dPOS` varchar(64) NOT NULL,
  `dOPIS` varchar(64) DEFAULT NULL,
  `rozmiar` smallint(5) unsigned NOT NULL DEFAULT '8',
  `aktywny` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_telecheckpoints`
--

LOCK TABLES `fs_telecheckpoints` WRITE;
/*!40000 ALTER TABLE `fs_telecheckpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_telecheckpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_telepickups`
--

DROP TABLE IF EXISTS `fs_telepickups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_telepickups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pX` double NOT NULL COMMENT 'Wspolrzedne pickupu',
  `pY` double NOT NULL,
  `pZ` double NOT NULL,
  `pi` int(11) NOT NULL COMMENT 'interior pickupu',
  `pvw` int(11) NOT NULL COMMENT 'vw pickupu',
  `opis` varchar(64) DEFAULT NULL COMMENT 'opis tekstowy',
  `pokazopis` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'czy opis ma sie pojawic przy pickupie',
  `pickupid` int(10) unsigned NOT NULL DEFAULT '19197' COMMENT 'id pickupu, domyslnie 19197',
  `mapicon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'ikonka na mapie, 0 - brak. lista pod http://wiki.sa-mp.com/wiki/MapIcons',
  `tX` double NOT NULL COMMENT 'dokad ma przenosic - wspolrzedne',
  `tY` double NOT NULL,
  `tZ` double NOT NULL,
  `ti` int(11) NOT NULL COMMENT 'dokad - interior',
  `tvw` mediumint(9) NOT NULL,
  `tA` double NOT NULL COMMENT 'dokad - kierunek patrzenia po przeniesieniu',
  `mapicon_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `opis_color` int(10) unsigned NOT NULL DEFAULT '16732697',
  `opis_drawdistance` smallint(5) unsigned NOT NULL DEFAULT '600',
  `restrict_gang` int(10) unsigned NOT NULL DEFAULT '0',
  `restrict_level` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=622 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_telepickups`
--

LOCK TABLES `fs_telepickups` WRITE;
/*!40000 ALTER TABLE `fs_telepickups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_telepickups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_til`
--

DROP TABLE IF EXISTS `fs_til`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_til` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tresc` varchar(1023) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_til`
--

LOCK TABLES `fs_til` WRITE;
/*!40000 ALTER TABLE `fs_til` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_til` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_vehicles`
--

DROP TABLE IF EXISTS `fs_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_vehicles` (
  `vid` smallint(3) unsigned NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `altnames` varchar(64) DEFAULT NULL,
  `cena` mediumint(8) unsigned NOT NULL DEFAULT '10000',
  `minPoziom` enum('gracz','vip','gm','admin') NOT NULL DEFAULT 'gracz',
  `jezdzi` tinyint(1) NOT NULL DEFAULT '1',
  `lata` tinyint(1) NOT NULL DEFAULT '0',
  `plywa` tinyint(1) NOT NULL DEFAULT '0',
  `wojskowy` tinyint(1) NOT NULL DEFAULT '0',
  `przyczepa` tinyint(1) NOT NULL DEFAULT '0',
  `tablica` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`vid`),
  KEY `minPoziom` (`minPoziom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_vehicles`
--

LOCK TABLES `fs_vehicles` WRITE;
/*!40000 ALTER TABLE `fs_vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `fs_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `fs_view_housesandvehicles`
--

DROP TABLE IF EXISTS `fs_view_housesandvehicles`;
/*!50001 DROP VIEW IF EXISTS `fs_view_housesandvehicles`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `fs_view_housesandvehicles` (
  `id` int(10) unsigned,
  `X` double,
  `Y` double,
  `Z` double,
  `exitX` float,
  `exitY` float,
  `exitZ` float,
  `exitA` float,
  `ownerid` decimal(11,0),
  `koszt` smallint(4) unsigned,
  `nick` varchar(24),
  `IFNULL
(h.paidTo,'-')` varbinary(10),
  `IFNULL(DATEDIFF(h.paidTo,NOW()),-1)` int(7),
  `homeX` float,
  `homeY` float,
  `homeZ` float,
  `homeA` float,
  `homeI` smallint(6),
  `homeVW` mediumint(9),
  `vehicles_allowed` tinyint(4),
  `vehicle_radius` double unsigned,
  `IFNULL(hv.model,0)` decimal(6,0),
  `IFNULL(hv.X,0)` double,
  `IFNULL(hv.Y,0)` double,
  `IFNULL(hv.Z,0)` double,
  `IFNULL(hv.A,0)` double,
  `IFNULL(hv.color1,0)` decimal(6,0),
  `IFNULL(hv.color2,0)` decimal(6,0),
  `IFNULL(hv.plate,"-
")` varchar(32),
  `IFNULL(audioURL,_latin1'-')` varchar(128),
  `IFNULL(``hv``.``components``,"-")` varchar(80),
  `restrict_gang` tinyint(2) unsigned
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `fs_wg_arena`
--

DROP TABLE IF EXISTS `fs_wg_arena`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_wg_arena` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descr` varchar(64) NOT NULL,
  `interior` smallint(5) unsigned NOT NULL DEFAULT '0',
  `minplayers` smallint(5) unsigned NOT NULL DEFAULT '2',
  `maxplayers` smallint(5) unsigned NOT NULL DEFAULT '2',
  `wb_cube` varchar(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL COMMENT 'prostopadloscian x1,y1,z1,x2,y2,z2',
  `wb_mode` enum('oraz','lub') CHARACTER SET ascii NOT NULL DEFAULT 'lub' COMMENT 'oraz - gracz musi byc w obu polach, lub - musi byc w jednym z nich',
  `wb_sphere` varchar(64) CHARACTER SET ascii DEFAULT NULL COMMENT 'kula/sfera: x,y,z,r',
  PRIMARY KEY (`id`),
  KEY `minplayers` (`minplayers`,`maxplayers`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_wg_arena`
--

LOCK TABLES `fs_wg_arena` WRITE;
/*!40000 ALTER TABLE `fs_wg_arena` DISABLE KEYS */;
INSERT INTO `fs_wg_arena` VALUES (1,'Las Barrancas',0,2,6,NULL,'lub','-766,1550,27,50');
/*!40000 ALTER TABLE `fs_wg_arena` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fs_wg_arena_sp`
--

DROP TABLE IF EXISTS `fs_wg_arena_sp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_wg_arena_sp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL,
  `team` tinyint(1) unsigned NOT NULL,
  `X` double NOT NULL,
  `Y` double NOT NULL,
  `Z` double NOT NULL,
  `A` double NOT NULL,
  `randomorder` tinyint(3) unsigned NOT NULL COMMENT 'wartosc losowa, aktualizowana automatycznie',
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`,`team`,`randomorder`)
) ENGINE=MyISAM AUTO_INCREMENT=2212 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fs_wg_arena_sp`
--

LOCK TABLES `fs_wg_arena_sp` WRITE;
/*!40000 ALTER TABLE `fs_wg_arena_sp` DISABLE KEYS */;
INSERT INTO `fs_wg_arena_sp` VALUES (1,1,0,-725.37,1546.64,39.02,90,0),(2,1,1,-795.81,1556.94,27.12,270,1),(3,1,0,-733.73,1555.07,39.81,260,1),(4,1,1,-797.19,1554.43,27.11,27.11,1),(5,1,0,-723.58,1537.86,40.36,88.25,0),(6,1,1,-796.99,1559.75,27.12,269.02,0);
/*!40000 ALTER TABLE `fs_wg_arena_sp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `fs_view_housesandvehicles`
--

/*!50001 DROP TABLE IF EXISTS `fs_view_housesandvehicles`*/;
/*!50001 DROP VIEW IF EXISTS `fs_view_housesandvehicles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE */
/*!50001 VIEW `fs_view_housesandvehicles` AS select `h`.`id` AS `id`,`h`.`X` AS `X`,`h`.`Y` AS `Y`,`h`.`Z` AS `Z`,`h`.`exitX` AS `exitX`,`h`.`exitY` AS `exitY`,`h`.`exitZ` AS `exitZ`,`h`.`exitA` AS `exitA`,ifnull(`h`.`ownerid`,0) AS `ownerid`,`h`.`koszt` AS `koszt`,ifnull(`p`.`nick`,_ascii'nn') AS `nick`,ifnull(`h`.`paidTo`,_utf8'-') AS `IFNULL
(h.paidTo,'-')`,ifnull((to_days(`h`.`paidTo`) - to_days(now())),-(1)) AS `IFNULL(DATEDIFF(h.paidTo,NOW()),-1)`,`h`.`homeX` AS `homeX`,`h`.`homeY` AS `homeY`,`h`.`homeZ` AS `homeZ`,`h`.`homeA` AS `homeA`,`h`.`homeI` AS `homeI`,`h`.`homeVW` AS `homeVW`,`h`.`vehicles_allowed` AS `vehicles_allowed`,`h`.`vehicle_radius` AS `vehicle_radius`,ifnull(`hv`.`model`,0) AS `IFNULL(hv.model,0)`,ifnull(`hv`.`X`,0) AS `IFNULL(hv.X,0)`,ifnull(`hv`.`Y`,0) AS `IFNULL(hv.Y,0)`,ifnull(`hv`.`Z`,0) AS `IFNULL(hv.Z,0)`,ifnull(`hv`.`A`,0) AS `IFNULL(hv.A,0)`,ifnull(`hv`.`color1`,0) AS `IFNULL(hv.color1,0)`,ifnull(`hv`.`color2`,0) AS `IFNULL(hv.color2,0)`,ifnull(`hv`.`plate`,_latin1'-') AS `IFNULL(hv.plate,"-
")`,ifnull(`h`.`audioURL`,_latin1'-') AS `IFNULL(audioURL,_latin1'-')`,ifnull(`hv`.`components`,_latin1'-') AS `IFNULL(``hv``.``components``,"-")`,`h`.`restrict_gang` AS `restrict_gang` from ((`fs_houses` `h` left join `fs_players` `p` on((`p`.`id` = `h`.`ownerid`))) left join `fs_houses_vehicles` `hv` on(((`hv`.`houseid` = `h`.`id`) and (`h`.`ownerid` > 0) and (`h`.`paidTo` > cast(now() as date))))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-02-21 13:34:22
